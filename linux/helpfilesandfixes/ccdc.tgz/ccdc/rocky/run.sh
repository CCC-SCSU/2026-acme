#!/usr/bin/env bash
# run.sh -- ROCKY LINUX (foghorn .13 Wiki-Chat / sylvester .69 Video) launcher.  Covers: foghorn .13, sylvester .69
#   sudo bash run.sh d    DRY RUN  (prints what it would do, changes nothing)  <- do this first
#   sudo bash run.sh r    RECON    (inventory + backup + red-flag scan, no changes)
#   sudo bash run.sh      FULL     (guided, asks before every change)
KIT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
[ -f "$KIT/ccdc.sh" ] || { echo "Cannot find the kit. This folder must stay inside ccdc/."; exit 1; }
[ "$(id -u)" -eq 0 ] || { echo "run with sudo:  sudo bash run.sh $*"; exit 1; }
echo "================= ROCKY LINUX (foghorn .13 Wiki-Chat / sylvester .69 Video) ================="
sed -n '/^GOTCHAS/,/^END/p' "$(dirname "${BASH_SOURCE[0]}")/RUN.txt" | sed '1d;$d'
echo "======================================================"
read -r -p "Read the above. Press Enter to continue (Ctrl-C to stop)... " _ || true
exec bash "$KIT/go" "$@"
