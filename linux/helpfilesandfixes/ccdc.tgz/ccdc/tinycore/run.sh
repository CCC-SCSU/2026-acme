#!/bin/sh
# Tiny Core: the main kit does not apply here. This prints the notes and points you at plan-b.
D=$(cd "$(dirname "$0")" && pwd)
cat "$D/RUN.txt"
echo
echo "Nothing was run. Follow the ORDER section above, using ../plan-b/ scripts."
