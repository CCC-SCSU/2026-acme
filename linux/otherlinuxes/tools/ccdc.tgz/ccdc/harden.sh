#!/usr/bin/env bash
# SSH + sysctl hardening (+ optional cron/at lockdown). Backs up and validates sshd config before reloading.
# Env: PERMIT_ROOT=no|yes (default no)
#      ALLOW_USERS="you teammate"   SSH whitelist; include YOUR login + any scoring/service users or you lock yourselves out
#      PASSAUTH=yes|no              only changes PasswordAuthentication if you set it (default: leave as is)
#      NO_FWD=yes                   also disable TCP forwarding (breaks ssh -J / tunnels THROUGH this box)
#      SSH_PORT=NNNN                optional port change. Open it in the firewall FIRST. Fedora/SELinux needs semanage;
#                                   skipped on Ubuntu using ssh.socket.
#      LOCK_CRON=yes CRON_USERS="svc"   only root + these users may use crontab/at
export PATH="$PATH:/usr/sbin:/sbin:/usr/local/sbin"
[ "$(id -u)" -eq 0 ] || { echo "run as root"; exit 1; }
cfg=${SSHD_CONFIG:-/etc/ssh/sshd_config}; [ -f "$cfg" ] || { echo "no $cfg"; exit 1; }
bak=$cfg.bak.$(date +%s); cp -a "$cfg" "$bak"
restore(){ cp -a "$bak" "$cfg"; echo "$1 -- restored $bak"; exit 1; }
if [ -n "$SSH_PORT" ] && systemctl is-active --quiet ssh.socket 2>/dev/null; then
  echo "ssh.socket is active (Ubuntu 22.10+): Port in sshd_config is ignored, skipping SSH_PORT."; SSH_PORT=""
fi
keys="PermitRootLogin PermitEmptyPasswords MaxAuthTries X11Forwarding LoginGraceTime"
[ -n "$PASSAUTH" ]      && keys="$keys PasswordAuthentication"
[ "$NO_FWD" = yes ]     && keys="$keys AllowTcpForwarding"
[ -n "$ALLOW_USERS" ]   && keys="$keys AllowUsers"
[ -n "$SSH_PORT" ]      && keys="$keys Port"
for k in $keys; do sed -i "s/^\s*$k\b/#&/" "$cfg"; done
{
  echo "PermitRootLogin ${PERMIT_ROOT:-no}"
  echo "PermitEmptyPasswords no"
  echo "MaxAuthTries 5"
  echo "LoginGraceTime 30"
  echo "X11Forwarding no"
  [ -n "$PASSAUTH" ]    && echo "PasswordAuthentication $PASSAUTH"
  [ "$NO_FWD" = yes ]   && echo "AllowTcpForwarding no"
  [ -n "$ALLOW_USERS" ] && echo "AllowUsers $ALLOW_USERS"
  [ -n "$SSH_PORT" ]    && echo "Port $SSH_PORT"
  cat "$cfg"
} > /tmp/sshd_new && install -m 600 /tmp/sshd_new "$cfg" && rm -f /tmp/sshd_new
command -v restorecon >/dev/null && restorecon "$cfg" 2>/dev/null
sshd -t || restore "sshd config invalid"
if [ -n "$SSH_PORT" ] && command -v getenforce >/dev/null && [ "$(getenforce)" = Enforcing ]; then
  command -v semanage >/dev/null || restore "SELinux enforcing but semanage missing (install policycoreutils-python-utils first)"
  semanage port -a -t ssh_port_t -p tcp "$SSH_PORT" 2>/dev/null || semanage port -m -t ssh_port_t -p tcp "$SSH_PORT"
fi
act=reload; [ -n "$SSH_PORT" ] && act=restart
unit=""
for u in sshd ssh; do systemctl cat "$u.service" >/dev/null 2>&1 && { unit=$u; break; }; done
if [ -n "$unit" ]; then
  if systemctl $act "$unit"; then echo "$unit ${act}ed."
  else echo "systemctl $act $unit FAILED -- restoring config"; restore "ssh $act failed"; fi
else echo "could not find an ssh/sshd unit; config written but NOT reloaded. Reload it yourself."; fi
echo "Keep this session open and test a NEW login before closing it."

if [ "$LOCK_CRON" = yes ]; then
  wrote=""
  command -v crontab >/dev/null && { { echo root; for u in $CRON_USERS; do echo "$u"; done; } > /etc/cron.allow; chmod 600 /etc/cron.allow; wrote="cron"; }
  command -v at      >/dev/null && { { echo root; for u in $CRON_USERS; do echo "$u"; done; } > /etc/at.allow;   chmod 600 /etc/at.allow;   wrote="$wrote at"; }
  if [ -n "$wrote" ]; then echo "limited to root $CRON_USERS:$wrote"
  else echo "no crontab/at installed (normal on Arch -- it uses systemd timers); nothing to lock."
       echo "Check timers instead:  systemctl list-timers --all"; fi
fi
sd=${SYSCTL_DIR:-/etc/sysctl.d}; mkdir -p "$sd"
cat > "$sd/99-ccdc.conf" <<EOT
net.ipv4.tcp_syncookies=1
net.ipv4.conf.all.rp_filter=2
net.ipv4.conf.all.accept_redirects=0
net.ipv4.conf.all.send_redirects=0
net.ipv4.conf.all.accept_source_route=0
net.ipv4.icmp_echo_ignore_broadcasts=1
EOT
command -v restorecon >/dev/null && restorecon "$sd/99-ccdc.conf" 2>/dev/null
sysctl -p "$sd/99-ccdc.conf" >/dev/null && echo "sysctl applied (only the 6 network settings in $sd/99-ccdc.conf)"
chmod o-rwx /etc/shadow /etc/gshadow 2>/dev/null; chmod go-w /etc/passwd /etc/group /etc/shadow 2>/dev/null
